//
//  ViewController.swift
//  BMICalculator
//
//  Created by Yunjia Gao on 5/2/22.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var txtWeight: UITextField!
    @IBOutlet weak var txtFeet: UITextField!
    @IBOutlet weak var txtInches: UITextField!
    @IBOutlet weak var lblBMI: UILabel!
    @IBOutlet weak var lblStatus: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    // Converting weight in lbs, height in feet and inches to weight in kilograms and height in meters
    @IBAction func calculateBMIAction(_ sender: Any) {
        guard let weight = txtWeight.text, !weight.isEmpty else {
            lblBMI.text = "Enter Weight"
            lblStatus.text = "Status:"
            return
        }
        guard let feet = txtFeet.text, !feet.isEmpty else {
            lblBMI.text = "Enter Feet"
            lblStatus.text = "Status:"
            return
        }
        guard let inches = txtInches.text, !inches.isEmpty else {
            lblBMI.text = "Enter Inches"
            lblStatus.text = "Status:"
            return
        }

        let height_in_inches = (feet as NSString).floatValue * 12 + (inches as NSString).floatValue
        let BMI = (weight as NSString).floatValue / pow(height_in_inches, 2) * 703
        
        lblBMI.text = "\(BMI)"
        if (BMI < 18.5){
            lblStatus.text = "You are now Underweight"
        } else if (BMI >= 18.5 && BMI < 25.0) {
            lblStatus.text = "You are in a Healthy Weight Range"
        } else if (BMI >= 25.0 && BMI < 30.0) {
            lblStatus.text = "You are looking Overweight"
        } else {
            lblStatus.text = "You fall in the Obesity Range"
        }

    }

    
}

