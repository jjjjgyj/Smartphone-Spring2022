//
//  URLConstants.swift
//  StockMaster
//
//  Created by Yunjia Gao on 2/27/22.
//

import Foundation

let urlShortQuote = "https://financialmodelingprep.com/api/v3/quote-short/"

