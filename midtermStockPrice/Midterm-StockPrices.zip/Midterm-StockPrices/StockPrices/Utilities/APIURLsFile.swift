//
//  APIURLsFile.swift
//  StockPrices
//
//  Created by Yunjia Gao on 4/10/22.
//

import Foundation

let companyQuoteURL = "https://financialmodelingprep.com/api/v3/quote/"
